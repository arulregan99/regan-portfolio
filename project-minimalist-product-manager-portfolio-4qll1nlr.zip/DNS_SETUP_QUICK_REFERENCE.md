# DNS Setup Quick Reference

## 🚀 Quick Start (5 Minutes)

### Step 1: Open DNS Guide
- Scroll to footer → Click "Custom Domain Setup"
- Or use in-app DNS guide link

### Step 2: Choose Provider
Select from: Namecheap, GoDaddy, Google Domains, Cloudflare, AWS Route 53, or Other

### Step 3: Select Record Type
- **CNAME** ← Recommended for most cases
- **A Record** ← If CNAME unavailable
- **ALIAS** ← For AWS/Cloudflare root domains

### Step 4: Copy DNS Values
Guide provides ready-to-copy:
- **Type:** CNAME | A | ALIAS
- **Name:** www (or @)
- **Value:** cname.blink.new (or IP)
- **TTL:** 3600 (or auto-detect)

### Step 5: Add to Provider
Log in → DNS Management → Add Record → Paste values → Save

### Step 6: Wait for Propagation
DNS changes take **24-48 hours** to propagate globally.

Check status at: `whatsmydns.net`

---

## 🔗 Provider Login Links

| Provider | URL | Time |
|----------|-----|------|
| **Namecheap** | `namecheap.com/domains` | 5 min |
| **GoDaddy** | `godaddy.com/domains` | 10 min |
| **Google Domains** | `google.com/domains` | 5 min |
| **Cloudflare** | `dash.cloudflare.com` | 10 min |
| **AWS Route 53** | `console.aws.amazon.com/route53` | 15 min |

---

## 📋 DNS Record Types Explained

### CNAME (Recommended) ⭐
```
Name:  www
Type:  CNAME
Value: cname.blink.new
TTL:   3600
```
**Use for:** Subdomains (www, blog, etc.)  
**Pros:** Simple, widely supported  
**Cons:** Can't use on root domain (@)  

### A Record (Alternative)
```
Name:  @ or yourdomain.com
Type:  A
Value: 198.51.100.1
TTL:   3600
```
**Use for:** Root domains or IP routing  
**Pros:** Works with root domains  
**Cons:** Less flexible than CNAME  

### ALIAS (Cloudflare/AWS)
```
Name:  @ (root)
Type:  ALIAS or ANAME
Value: alias.blink.new
TTL:   3600
```
**Use for:** AWS/Cloudflare only  
**Pros:** Works on root domain  
**Cons:** Provider-specific  

---

## ⏱️ DNS Propagation Timeline

| Time | Status |
|------|--------|
| **Immediate** | Record added to provider ✓ |
| **5-30 min** | Most resolvers updated |
| **2-6 hours** | ~90% coverage |
| **24-48 hours** | Full global propagation |

**Check Status:**
- Online: `whatsmydns.net` (visual)
- CLI: `nslookup yourdomain.com`
- CLI: `dig yourdomain.com`

---

## 🆚 Provider Comparison

| | Namecheap | GoDaddy | Google | Cloudflare | AWS |
|---|-----------|---------|--------|-----------|-----|
| **Ease** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐ |
| **Speed** | 5 min | 10 min | 5 min | 10 min | 15 min |
| **Support** | Excellent | Good | Excellent | Good | Technical |
| **Cost** | $ | $$ | $ | Free | $$ |
| **Features** | Basic | Full | Full | Advanced | Enterprise |

---

## ✅ Verification Checklist

- [ ] Domain purchased and active
- [ ] DNS provider account logged in
- [ ] Record type selected (CNAME/A/ALIAS)
- [ ] All values copied correctly
- [ ] DNS record added to provider
- [ ] TTL set to reasonable value
- [ ] Record saved in provider dashboard
- [ ] Waited 24-48 hours for propagation
- [ ] Domain accessible at custom URL
- [ ] SSL certificate working (HTTPS)

---

## 🚨 Troubleshooting Flowchart

```
Domain not working?
├─ → Check DNS propagation at whatsmydns.net
│   ├─ Not showing? → Wait 24-48 hours
│   └─ Shows but site doesn't work? → Continue...
│
├─ → Verify DNS values match exactly
│   ├─ Type correct? ✓
│   ├─ Name correct? ✓
│   ├─ Value correct? ✓
│   └─ One doesn't match? → Update provider
│
├─ → Clear browser cache
│   ├─ Windows: Ctrl+Shift+Delete
│   └─ Mac: Cmd+Shift+Delete
│
├─ → Disable browser extensions
│   └─ VPN/proxy issues?
│
└─ → Contact support with error details
```

---

## 📞 Common Issues & Fixes

### "Domain not loading"
1. Wait 24-48 hours for DNS propagation
2. Check `whatsmydns.net` for your domain
3. Verify all DNS values match exactly
4. Try different browser/device

### "Certificate error (HTTPS)"
1. Usually resolves during DNS propagation
2. After propagation, refresh and try HTTPS
3. If persists, check SSL certificate status

### "DNS shows in checker but site down"
1. DNS is correct, but site may be down
2. Check Blink deployment status
3. Try at different time
4. Contact support if issue persists

### "Changed DNS but no effect"
1. Clear browser cache (Ctrl+Shift+Delete)
2. Clear DNS cache locally:
   - **Windows:** `ipconfig /flushdns`
   - **Mac:** `sudo dscacheutil -flushcache`
   - **Linux:** `sudo systemctl restart systemd-resolved`
3. Wait another 1-2 hours for propagation

### "Added wrong record type"
1. Log in to DNS provider
2. Delete the incorrect record
3. Create new record with correct type
4. Follow guide again
5. Wait for new propagation

---

## 🔑 Key DNS Terms

| Term | Meaning |
|------|---------|
| **DNS** | Domain Name System (translates domains to IPs) |
| **Record** | Single DNS entry (Name, Type, Value) |
| **TTL** | Time-to-Live (how long resolver caches it) |
| **Propagation** | Time for changes to spread globally |
| **CNAME** | Alias pointing to another domain |
| **A Record** | Points to IP address directly |
| **Value** | Where record points to (domain or IP) |
| **MX Record** | Email routing (not needed for websites) |

---

## 📊 DNS Record Examples

### Example 1: www subdomain (Namecheap)
```
Name:     www
Type:     CNAME  
Value:    cname.blink.new
TTL:      3600
Priority: (leave empty)
Weight:   (leave empty)
Port:     (leave empty)
```

### Example 2: Root domain (AWS Route 53)
```
Name:         (leave blank for root)
Type:         ALIAS (for Blink)
Alias Target: alias.blink.new
Alias Zone:   (auto-populated)
TTL:          3600
Routing:      Simple
```

### Example 3: Root domain (Cloudflare)
```
Type:     ALIAS or CNAME
Name:     @
Content:  alias.blink.new
TTL:      3600 (or auto)
Proxy:    DNS only (or Proxied)
```

---

## 🎯 Pro Tips

1. **Use lower TTL before changes**
   - Set TTL to 300 (5 min) before updating
   - Allows faster testing and rollback
   - After working, increase to 3600

2. **Document your DNS records**
   - Screenshot setup
   - Save DNS values somewhere secure
   - Make migration easier later

3. **Test with different locations**
   - Global propagation might be uneven
   - Use `whatsmydns.net` to check worldwide
   - Or test from different countries

4. **SSL/HTTPS automatic**
   - After DNS setup complete
   - HTTPS usually works within 48 hours
   - If not working, force refresh

5. **Set domain as primary**
   - After DNS works, update bookmarks
   - Update any links pointing to old URL
   - Redirect old URL to new domain

---

## 📚 Additional Resources

- **What is DNS?** → `cloudflare.com/learning/dns`
- **DNS Checker** → `mxtoolbox.com`
- **Propagation Checker** → `whatsmydns.net`
- **Command Line Help** → `nslookup` / `dig` guides
- **Provider Support** → Search their help center
- **Blink Docs** → `blink.new/docs/domains`

---

## ⏰ Time Estimates

| Task | Time |
|------|------|
| Buy domain | 5 min |
| Access DNS settings | 2 min |
| Copy DNS values | 1 min |
| Add DNS record | 5 min |
| **Total setup** | **13 min** |
| Wait for propagation | 24-48 hours |

---

**Last Updated:** 2025-11-17  
**Version:** 1.0  
**For Help:** Click "Custom Domain Setup" in footer
